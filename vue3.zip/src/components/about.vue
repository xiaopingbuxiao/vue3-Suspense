<template>
  <h1>这是about页面</h1>
</template>
<script>
import { Sleep } from "../util/index";
import { onUnmounted } from "vue";

export default {
  async setup() {
    let data;
    onUnmounted(() => {
      data.cancle();
    });
    data = new Sleep(1000);
    await data.promise();
  }
};
</script>