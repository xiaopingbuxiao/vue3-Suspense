
<template>
  <h1>这是home页面</h1>
</template>
<script>
import { Sleep } from "../util/index";
import { onUnmounted } from "vue";

export default {
  async setup() {
    let data;
    onUnmounted(() => {
      console.log(data)
      data.cancle();
    });
    data = new Sleep(2000);
    await data.promise();
  }
};
</script>