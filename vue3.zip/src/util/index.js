// export const sleep = time => {
//   let reslove, reject, timer;
//   timer = setTimeout(() => {
//     clearTimeout(timer)
//     reslove();
//   }, time);
//   sleep.cancle = function () {
//     clearTimeout(timer)
//     reject()
//   }
//   return new Promise((resloveP, rejectP) => {
//     reslove = resloveP
//     reject = rejectP
//   });
// };


export class Sleep {
  constructor(wait = 1000) {
    this.reject = null
    this.reslove = null
    this.timer = null
    this.wait = wait
  }
  promise() {
    this.timer = setTimeout(() => {
      clearTimeout(this.timer)
      this.reslove()
    }, this.wait)
    return new Promise((resloveP, rejectP) => {
      this.reslove = resloveP
      this.reject = rejectP
    })
  }
  cancle() {
    clearTimeout(this.timer)
    this.reject()
  }
}

